package com.databaseProject.DatabaseProject.Controler;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CategoriesController {
    @GetMapping(value = "/category" )
    public String getPage() {
        return "Welcome";
    }

}
