package com.databaseProject.DatabaseProject.Models;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Article {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Article_id;

    @Column
    private boolean Article_status;

    @Column
    private String title;

    @Column
    private long Author_id;

    @Column(columnDefinition = "TEXT")
    private String metaData;


    @Column(columnDefinition = "TEXT")
    private String content;

    @Column
    private LocalDateTime createdAt;

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    private User user;


    @ManyToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL )

    @JoinTable(
            name = "Article_Categories",
            joinColumns = { @JoinColumn(name = "Article_id") },
            inverseJoinColumns = { @JoinColumn(name = "Category_id") }
    )

    private Set<com.databaseProject.DatabaseProject.Models.Categories> Categories = new HashSet<>();


    @OneToMany(mappedBy = "Article")
    private Set<com.databaseProject.DatabaseProject.Models.Comments> Comments = new HashSet<>();



    @OneToMany(mappedBy = "Article")
    private Set<LikeArticle> Like = new HashSet<>();

    public String getMetaData() {return metaData;}

    public void setMetaData(String metaData) {this.metaData = metaData;}

    public long getAuthor_id() {return Author_id;}

    public void setAuthor_id(long author_id) {Author_id = author_id;}

    public long Article_id() {
        return Article_id;
    }

    public void setArticle_id(long Article_id) {
        this.Article_id = Article_id;
    }

    public Set<com.databaseProject.DatabaseProject.Models.Categories> getCategories() {
        return Categories;
    }

    public User getUser() {
        return user;
    }

    public Set<com.databaseProject.DatabaseProject.Models.Comments> getComments() {
        return Comments;
    }

    public Set<LikeArticle> getLike() {
        return Like;
    }
    public long getArticle_id() {
        return Article_id;
    }

    public boolean isArticle_status() {
        return Article_status;
    }

    public void setArticle_status(boolean article_status) {
        Article_status = article_status;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setCategories(Set<com.databaseProject.DatabaseProject.Models.Categories> categories) {
        Categories = categories;
    }

    public void setComments(Set<com.databaseProject.DatabaseProject.Models.Comments> comments) {
        Comments = comments;
    }

    public void setLike(Set<LikeArticle> like) {
        Like = like;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }


}
