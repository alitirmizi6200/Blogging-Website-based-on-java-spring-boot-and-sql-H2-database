package com.databaseProject.DatabaseProject.Controler;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LikeController {
    @GetMapping(value = "/like" )
    public String getPage() {
        return "Welcome";
    }

}
