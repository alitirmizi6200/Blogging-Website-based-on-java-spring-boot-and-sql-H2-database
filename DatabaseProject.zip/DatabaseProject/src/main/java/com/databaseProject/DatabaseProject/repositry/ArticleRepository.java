package com.databaseProject.DatabaseProject.repositry;

import com.databaseProject.DatabaseProject.Models.Article;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ArticleRepository extends JpaRepository<Article,Long> {
}
