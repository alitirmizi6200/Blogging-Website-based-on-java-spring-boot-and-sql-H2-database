package com.databaseProject.DatabaseProject.Models;
import javax.persistence.*;

@Entity
public class LikeArticle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long like_id;

    @Column
    private boolean Like_status;


    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    private User User;



    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "Article_id", referencedColumnName = "Article_id")
    private Article Article;


    public long getLike_id() {
        return like_id;
    }

    public void setLike_id(long like_id) {
        this.like_id = like_id;
    }

    public boolean isStatus() {
        return Like_status;
    }

    public User getUser() {
        return User;
    }
    public Article getArticle() {
        return Article;
    }
    public void setStatus(boolean status) {
        this.Like_status = status;
    }

}
