package com.databaseProject.DatabaseProject.Models;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;


@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long user_id;
    @Column

    private String username;
    @Column
    private String password;
    @Column
    private String email;
    @Column
    private Long About;

    @Column
    private boolean user_status;



    @ManyToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL )

    @JoinTable(
            name = "User_Interest",
            joinColumns = { @JoinColumn(name = "user_id") },
            inverseJoinColumns = { @JoinColumn(name = "Category_id") }
    )



    private Set<com.databaseProject.DatabaseProject.Models.Categories> Categories = new HashSet<>();




    @OneToMany(mappedBy = "user")
    private Set<com.databaseProject.DatabaseProject.Models.Article> Article = new HashSet<>();



    @OneToMany(mappedBy = "user")
    private Set<com.databaseProject.DatabaseProject.Models.Comments> Comments = new HashSet<>();



    @OneToMany(mappedBy = "User")
    private Set<LikeArticle> LikeArticle = new HashSet<>();



    public Long getAbout() {return About;}

    public void setAbout(Long about) {About = about;}

    public long getUser_id() {
        return user_id;
    }

    public void setUser_id(long user_id) {
        this.user_id = user_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public boolean isUser_status() {
        return user_status;
    }

    public void setUser_status(boolean user_status) {
        this.user_status = user_status;
    }

    public Set<com.databaseProject.DatabaseProject.Models.Categories> getCategories() {
        return Categories;
    }

    public void setCategories(Set<com.databaseProject.DatabaseProject.Models.Categories> categories) {
        Categories = categories;
    }

    public Set<com.databaseProject.DatabaseProject.Models.Article> getArticle() {
        return Article;
    }

    public void setArticle(Set<com.databaseProject.DatabaseProject.Models.Article> article) {
        Article = article;
    }

    public Set<com.databaseProject.DatabaseProject.Models.Comments> getComments() {
        return Comments;
    }

    public void setComments(Set<com.databaseProject.DatabaseProject.Models.Comments> comments) {
        Comments = comments;
    }

    public Set<com.databaseProject.DatabaseProject.Models.LikeArticle> getLikeArticle() {
        return LikeArticle;
    }

    public void setLikeArticle(Set<com.databaseProject.DatabaseProject.Models.LikeArticle> likeArticle) {
        LikeArticle = likeArticle;
    }
}
