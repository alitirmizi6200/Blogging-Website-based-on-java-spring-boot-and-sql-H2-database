package com.databaseProject.DatabaseProject.repositry;

import com.databaseProject.DatabaseProject.Models.Comments;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentsRepository extends JpaRepository<Comments,Long> {
}
