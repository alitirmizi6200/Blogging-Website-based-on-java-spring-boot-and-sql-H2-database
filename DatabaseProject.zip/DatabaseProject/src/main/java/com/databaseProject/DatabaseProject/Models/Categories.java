package com.databaseProject.DatabaseProject.Models;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "Categories")
public class Categories {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Category_id;

    @Column
    private String Category_name;


    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "Categories")
    private Set<com.databaseProject.DatabaseProject.Models.User > user = new HashSet<>();

    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "Categories")
    private Set<com.databaseProject.DatabaseProject.Models.Article> Article = new HashSet<>();


    public long getCategory_id() {
        return Category_id;
    }

    public void setCategory_id(long category_id) {
        Category_id = category_id;
    }

    public String getCategory_name() {
        return Category_name;
    }

    public void setCategory_name(String category_name) {
        Category_name = category_name;
    }

    public Set<User> getUser() {
        return user;
    }

}
