package com.databaseProject.DatabaseProject.Config;

import com.databaseProject.DatabaseProject.Models.Article;
import com.databaseProject.DatabaseProject.Services.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class seedData implements CommandLineRunner {

    public long user_id;
    public String username;

    public boolean checkuser( String username){
        this.username = username;
        return true;
    }
    @Autowired
    private ArticleService  articleService;

    @Override
    public void run(String... args) throws Exception{
        List<Article> article = articleService.getAll();


            Article article1 = new Article();
            article1.setTitle("This is Title 1");
            article1.setContent("Ukraine War, 8–9 July 2022");
            article1.setArticle_status(true);

            articleService.save(article1);


    }

}
