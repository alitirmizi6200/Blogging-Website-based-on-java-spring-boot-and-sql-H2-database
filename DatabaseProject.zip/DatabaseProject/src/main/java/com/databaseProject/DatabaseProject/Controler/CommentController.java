package com.databaseProject.DatabaseProject.Controler;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CommentController {
    @GetMapping(value = "/comment" )
    public String getPage() {
        return "Welcome";
    }

}
