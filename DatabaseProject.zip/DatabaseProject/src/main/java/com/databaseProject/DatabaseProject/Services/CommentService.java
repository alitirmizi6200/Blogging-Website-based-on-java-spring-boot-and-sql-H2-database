package com.databaseProject.DatabaseProject.Services;


import com.databaseProject.DatabaseProject.Models.Comments;
import com.databaseProject.DatabaseProject.repositry.CommentsRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public class CommentService {

    @Autowired
    private CommentsRepository commentsRepository;

    public Optional<Comments> getById(Long comment_id){

        return commentsRepository.findById(comment_id);

    }
    public List<Comments> getAll(){
        return commentsRepository.findAll();
    }

    public Comments save(Comments comments){

        comments.setCreatedAt(LocalDateTime.now());

        return commentsRepository.save(comments);

    }
}
