package com.databaseProject.DatabaseProject.Models;
import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Comments {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long comment_id;
    @Column
    private String comment_description;

    @Column
    private boolean Comment_status;
    @Column
    private long author_id;

    @Column
    private LocalDateTime createdAt;


    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    private User user;


    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "Article_id", referencedColumnName = "Article_id")
    private Article Article;




    public LocalDateTime getCreatedAt() {return createdAt;}

    public long getAuthor_id() {return author_id;}

    public void setAuthor_id(long author_id) {this.author_id = author_id;}
    public void setCreatedAt(LocalDateTime createdAt) {this.createdAt = createdAt;}

    public long getComment_id() {
        return comment_id;
    }

    public void setComment_id(long comment_id) {
        this.comment_id = comment_id;
    }

    public String getComment_description() {
        return comment_description;
    }

    public void setComment_description(String comment_description) {
        this.comment_description = comment_description;
    }

    public com.databaseProject.DatabaseProject.Models.Article getArticle() {
        return Article;
    }

    public User getUser() {
        return user;
    }
    public boolean isComment_status() {
        return Comment_status;
    }

    public void setComment_status(boolean comment_status) {
        Comment_status = comment_status;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setArticle(com.databaseProject.DatabaseProject.Models.Article article) {
        Article = article;
    }
}
