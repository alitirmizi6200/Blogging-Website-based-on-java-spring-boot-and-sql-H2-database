package com.databaseProject.DatabaseProject.repositry;

import com.databaseProject.DatabaseProject.Models.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
}
