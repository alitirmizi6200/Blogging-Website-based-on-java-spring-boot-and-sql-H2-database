package com.databaseProject.DatabaseProject.Services;

import com.databaseProject.DatabaseProject.Models.Article;
import com.databaseProject.DatabaseProject.Models.User;
import com.databaseProject.DatabaseProject.repositry.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public Optional<User> getById(Long user_id){

        return userRepository.findById(user_id);

    }
    public List<User> getAll(){
        return userRepository.findAll();
    }
    
    public User save(User user){

        return userRepository.save(user);

    }

}