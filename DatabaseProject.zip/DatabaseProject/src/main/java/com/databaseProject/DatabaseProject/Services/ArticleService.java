package com.databaseProject.DatabaseProject.Services;

import com.databaseProject.DatabaseProject.Models.Article;
import com.databaseProject.DatabaseProject.repositry.ArticleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ArticleService {
    @Autowired
    private ArticleRepository articleRepository;

    public Optional<Article> getById(Long Article_id){

        return articleRepository.findById(Article_id);

    }
    public List<Article> getAll(){
        return articleRepository.findAll();
    }

    public Article save(Article article){

        article.setCreatedAt(LocalDateTime.now());

        return articleRepository.save(article);

    }

}
